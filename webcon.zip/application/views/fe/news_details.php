
<div class="clear"></div>
<!-- banner_inner start -->
<div class="banner_inner">
 <img src="<?php echo site_url('images/sub/phato-g.jpg')?>" alt="" />
</div>
<!-- banner_inner end -->

<!-- content area start -->

<div class="content_area">

<h2>News <span>&amp; Details</span></h2>

<table cellpadding="0" cellspacing="10">
<tbody>
<tr>
<td class="news_title"><?php echo $newsContent->title;?></td>
</tr>
<tr>
<td class="desrp">
<?php echo $newsContent->description;?>

</td>
</tr>
</tbody>
</table>







<div class="clear"></div>
</div>

<!-- content area end -->








<div class="clear"></div>
</div>  
<!-- wrappr end -->
<div class="clear"></div>
