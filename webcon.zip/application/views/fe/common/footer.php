<!-- Footer start -->
<div class="footer">
    <div id="footer_content">
    <div class="foot_link">
    <ul class="first_link">
    <li><a href="#">Enquiry</a> <span>|</span></li>  
    <li><a href="#">Services</a> <span>|</span></li>   
    <li><a href="#">Our Team</a> <span>|</span></li> 
    <li><a href="#">Recruitment</a> <span>|</span></li> 
    <li><a href="#">Photo Gallery</a> <span>|</span></li> 
    <li><a href="#">Site Map</a> <span>|</span></li> 
    <li><a href="#">Contact Us</a></li> 
    </ul>
    <div class="clear"></div>
    <ul class="second_link">
    <li><a href="#">Privacy Policy</a> <span>|</span></li>  
    <li><a href="#">Disclaimer</a> <span>|</span></li>   
    <li><a href="#">Terms &amp; Conditions</a></li> 
    </ul>
    </div>
    <div class="footer_address">
    <h6>Webcon Consulting (India) Ltd.</h6>
    <ul>
    <li>Chatterjee International Centre, 4th Floor</li>
    <li>33A, Jawaharlal Nehru Road</li>
    <li>Kolkata – 700 071, West Bengal, India</li>
    <li>Phone: (033) 22266527/ 6278 , 40706060/61  <span>|</span>  Fax: (033) 22881884</li>
    <li>Email: <a href="mailto:info@webcon.in">info@webcon.in</a>  <span>|</span> Website: <a href="http://www.webcon.in" target="_blank">www.webcon.in</a></li>

    </ul>
    </div>
    </div>
<div class="clear"></div>
</div>
<div class="clear"></div>
<div class="copyright">
<div class="copyright_txt">Copyright &copy; 2012. Webcon Consulting (India) Ltd. All rights reserved.</div>
</div>
<!-- Footer end -->
</body>
</html>
